const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const router = express.Router();
const port = process.env.PORT || 3001;
const akcje = require('./akcje');

const app = express();
app.use(bodyParser.json());
app.use(cors());
app.use('/', router);

app.get('/api1', (req, res) => {
    console.log("Dostałem GET");
    res.send("Witaj na serwerze");
});

router.get('/api', akcje.akcjaGet);

router.get('/apiParam', akcje.akcjaGetParam)

router.post('/api', akcje.akcjaPost);

router.post('/apiParam', akcje.akcjaPostParam);

router.delete('/api', akcje.akcjaDelete);

// Obsługa bazy danych
//Get odczyt z bazy - kwerenda
router.get('/apiBaza', akcje.getBaza);

//Get odczyt z bazy - kwerenda jako parametr
router.get('/apiBazaPar', akcje.getBazaPar);

//******************* 
//server

app.listen(port, () => {
    console.log(`Server słucha na porcie ${port}`);
});