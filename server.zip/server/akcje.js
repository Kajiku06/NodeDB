const link = require('./create_connection');

const lista1 = [
    {imie: 'Jan', nazwisko: 'Kowalski'},
    {imie: 'Janusz', nazwisko: 'Kowalewski'}
]

const lista2 = [
    {imie: 'Jan', nazwisko: 'Abecki'},
    {imie: 'Adam', nazwisko: 'Bebecki'}
]
class Akcje {
    akcjaGet(req, res) {
        console.log('Odebrałem żądanie GET');
        res.status(200);
        res.json(lista1);
    }

    akcjaGetParam(req, res) {
        console.log("Get z parametram");
        const dane = req.query.dane;
        res.status(200);
        if (dane == 1) res.json(lista1);
        else res.json(lista2);
    }

    akcjaPost(req, res) {
        console.log("Post");
        res.status(200);
        res.json(lista2);
    }

    akcjaPostParam(req, res) {
        console.log("POST z parametrami");
        const imie = req.body.imie;
        const nazwisko = req.body.nazwisko;
        lista1[0].imie = imie;
        lista1[0].nazwisko = nazwisko;
        res.status(200);
        res.json(lista1);
    }

    akcjaDelete(req, res) {
        console.log("MAM Delete");
        res.status(200);
        res.send("Dane skasowane");
    }

    getBaza(req, res) {
        const sql = `SELECT * FROM czytelnicy`;
        link.query(sql, (err, results, fields) => {
            if (err) {
                return console.error(err.message);
            }
            console.table(results);
            res.status(200).json(results);
        });
    }

    getBazaPar(req, res) {
        const sql = req.query.sql
        console.log(`Kwerenda$ ${sql}`)
        link.query(sql,(err, results, fields) =>{
            if (err){
                return console.error(err.message);
            }
            console.table(results)
            res.status(200).json(results)
        }
        )
    }
    postBaza(req, res) {
        const sql = req.body.sql
        console.log(`Kwerenda$ ${sql}`)
        link.query(sql,(err, results, fields) =>{
            if (err){
                return console.error(err.message);
            }
            console.table(results)
            res.status(200).json(results)
        }
        )
    }
    

}

module.exports = new Akcje();