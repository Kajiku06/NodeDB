let mysql = require('mysql');
console.log("Mam połączenie z bazą");

const link = mysql.createConnection({
    host: 'localhost',
    port: '3306',
    user: 'root',
    password: '',
    database: 'biblioteka'
});

link.connect(function(err) {
    if (err) {
        return console.log(`błąd: ${err.message}`);
    }
    console.log("połączenie uzyskane");
});

module.exports = link;